//Using XMLHttpRequest for Staff
document.getElementById("staffButton").addEventListener("click", function () {
    const xhttp = new XMLHttpRequest();

    xhttp.addEventListener("load", function () {
        const staff = JSON.parse(this.responseText);
        let output = "<h2>Our Teaching Staff</h2>";
        staff.forEach(member => {
            output += `<p><strong>${member.name}</strong>: ${member.role}</p>`;
        });

        document.getElementById("result").innerHTML = output;
    });

    xhttp.open("GET", "data/staff.json");
    xhttp.send();
});
//Using Fetch API for Subjects
document.getElementById("subjectsButton").addEventListener("click", function () {
    fetch("data/subject.json")
        .then(response => response.json())
        .then(subjects => {
            let output = "<h2>Subjects We Teach</h2>";
            subjects.forEach(subject => {
                output += `<p><strong>${subject.name}</strong>: ${subject.description}</p>`;
            });

            document.getElementById("result").innerHTML = output;
        });
});
