const express = require("express");
const db = require("./database");
const app = express();

// Set EJS as the view engine
app.set("view engine", "ejs");

// Serve static files (CSS, images, etc.)
app.use(express.static("public"));

// Home route
app.get("/", (req, res) => {
    res.render("layout", { title: "Hogwarts Home", body: "<h1>Welcome to Hogwarts!</h1>" });
});

// Staff route
app.get("/staff", (req, res) => {
    db.all("SELECT * FROM Staff", [], (err, rows) => {
        if (err) {
            return res.status(500).send("Error retrieving staff data");
        }
        res.render("staff", { title: "Staff Members", staff: rows });
    });
});

// Single staff member route
app.get("/staff/:id", (req, res) => {
    const id = req.params.id;
    db.get("SELECT * FROM Staff WHERE id = ?", [id], (err, row) => {
        if (err || !row) {
            return res.status(404).send("Staff member not found");
        }
        res.render("staffDetail", { title: "Staff Details", staff: row });
    });
});

// Subjects route
app.get("/subjects", (req, res) => {
    db.all("SELECT * FROM Subjects", [], (err, rows) => {
        if (err) {
            return res.status(500).send("Error retrieving subjects data");
        }
        res.render("subjects", { title: "Subjects", subjects: rows });
    });
});

// Single subject route
app.get("/subjects/:id", (req, res) => {
    const id = req.params.id;
    db.get("SELECT * FROM Subjects WHERE id = ?", [id], (err, row) => {
        if (err || !row) {
            return res.status(404).send("Subject not found");
        }
        res.render("subjectDetail", { title: "Subject Details", subject: row });
    });
});

// Start the server
app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});
