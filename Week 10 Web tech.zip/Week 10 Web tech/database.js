const sqlite3 = require("sqlite3").verbose();
const db = new sqlite3.Database("./hogwarts.db");

db.serialize(() => {
    // Create Staff table
    db.run(`
        CREATE TABLE IF NOT EXISTS Staff (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            role TEXT NOT NULL,
            house TEXT
        )
    `);

    // Create Subjects table
    db.run(`
        CREATE TABLE IF NOT EXISTS Subjects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            teacher TEXT NOT NULL
        )
    `);

    // Insert sample data
    db.run(`INSERT INTO Staff (name, role, house) VALUES ('Minerva McGonagall', 'Headmistress', 'Gryffindor')`);
    db.run(`INSERT INTO Staff (name, role, house) VALUES ('Severus Snape', 'Professor', 'Slytherin')`);
    db.run(`INSERT INTO Subjects (name, teacher) VALUES ('Potions', 'Severus Snape')`);
    db.run(`INSERT INTO Subjects (name, teacher) VALUES ('Transfiguration', 'Minerva McGonagall')`);
});

module.exports = db;
