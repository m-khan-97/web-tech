document.getElementById("staffButton").addEventListener("click", function () {
    const xhttp = new XMLHttpRequest();

xhttp.addEventListener("load", function () {
    const staff = JSON.parse(this.responseText);
    let output = `
        <h2>Our Teaching Staff</h2>
        <table>
            <tr>
                <th>Name</th>
                <th>Role</th>
            </tr>`;
    staff.forEach(member => {
        output += `
            <tr>
                <td>${member.name}</td>
                <td>${member.role}</td>
            </tr>`;
    });
    output += `</table>`;

    document.getElementById("result").innerHTML = output;
});

xhttp.open("GET", "data/staff.json");
xhttp.send();
});

document.getElementById("subjectsButton").addEventListener("click", function () {

fetch("data/subject.json")
    .then(response => response.json())
    .then(subjects => {
        let output = `
            <h2>Subjects We Teach</h2>
            <table>
                <tr>
                    <th>Subject</th>
                    <th>Description</th>
                </tr>`;
        subjects.forEach(subject => {
            output += `
                <tr>
                    <td>${subject.name}</td>
                    <td>${subject.description}</td>
                </tr>`;
        });
        output += `</table>`;

        document.getElementById("result").innerHTML = output;
    });
});