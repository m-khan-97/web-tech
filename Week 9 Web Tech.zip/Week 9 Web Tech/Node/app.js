const express = require("express");
const path = require("path");
const app = express();
const port = 3000;

// Set up EJS as the templating engine
app.set("view engine", "ejs");

// Serve static files (CSS, JS, images) from the "public" folder
app.use(express.static(path.join(__dirname, "public")));

// Routes
app.get("/", (req, res) => {
    res.render("home", { title: "Welcome to Hogwarts" });
});

app.get("/houses", (req, res) => {
    res.render("houses", { title: "Hogwarts Houses Quiz" });
});

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
