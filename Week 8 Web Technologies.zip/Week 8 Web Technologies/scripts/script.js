// Bar Class Definition
class Bar {
    constructor() {
        // Initialize health to 100
        this.health = 100;

        // Create container div
        this.container = document.createElement('div');
        this.container.classList.add('bar');
        document.body.appendChild(this.container);

        // Create health bar div
        this.healthbar = document.createElement('div');
        this.healthbar.classList.add('health');
        this.container.appendChild(this.healthbar);

        // Initial update
        this.update();

        // Add click event to decrease health
        this.container.addEventListener('click', () => {
            this.decreaseHealth();
        });

        // Add mouseover event to increase health
        this.container.addEventListener('mouseover', () => {
            this.increaseHealth();
        });
    }

    update() {
        // Update health bar width based on health
        this.healthbar.style.width = `${this.health}%`;
    }

    decreaseHealth() {
        // Decrease health but prevent it from going below 0
        if (this.health > 0) {
            this.health -= 10;
            this.update();
        }
    }

    increaseHealth() {
        // Increase health but prevent it from exceeding 100
        if (this.health < 100) {
            this.health += 30;
            if (this.health > 100) this.health = 100;
            this.update();
        }
    }
}

// Add Bar on Button Click
document.getElementById('addBar').addEventListener('click', () => {
    new Bar();
});
