document.getElementById("contactForm").addEventListener("submit", function (e) {
    e.preventDefault(); // Prevent form submission

    // Get form fields
    const name = document.getElementById("name");
    const email = document.getElementById("email");
    const owls = document.getElementById("owls");
    const query = document.getElementById("query");
    const packageStandard = document.getElementById("standard");
    const packageChosenOne = document.getElementById("chosenOne");

    // Clear previous error messages
    clearErrors();

    // Validation
    let isValid = true;

    if (!name.value.trim()) {
        showError(name, "Name is required.");
        isValid = false;
    }

    if (!email.value.trim() || !validateEmail(email.value)) {
        showError(email, "A valid email is required.");
        isValid = false;
    }

    if (!owls.value || owls.value < 1 || owls.value > 10) {
        showError(owls, "Please enter a number between 1 and 10.");
        isValid = false;
    }

    if (!packageStandard.checked && !packageChosenOne.checked) {
        showError(packageStandard.closest("form"), "Please select a package.");
        isValid = false;
    }

    if (!query.value.trim()) {
        showError(query, "Query is required.");
        isValid = false;
    }

    if (isValid) {
        alert("Form submitted successfully!");
        this.submit(); // Submit the form programmatically
    }
});

// Clear errors function
function clearErrors() {
    const errors = document.querySelectorAll(".error-message");
    errors.forEach((error) => error.remove());

    const fields = document.querySelectorAll(".error");
    fields.forEach((field) => field.classList.remove("error"));
}

// Show error function
function showError(field, message) {
    field.classList.add("error");
    const error = document.createElement("span");
    error.classList.add("error-message");
    error.textContent = message;
    field.parentNode.insertBefore(error, field.nextSibling);
}

// Email validation function
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}
