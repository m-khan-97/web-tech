// Function to proceed to the next question
function nextQuestion(questionNum) {
    // Hide the current question
    const currentQuestionEl = document.getElementById(`question${questionNum}`);
    currentQuestionEl.style.display = 'none';

    // Show the next question
    const nextQuestionEl = document.getElementById(`question${questionNum + 1}`);
    if (nextQuestionEl) {
        nextQuestionEl.style.display = 'block';
    }
}

// Function to display the final result and assign house
function displayResult(house) {
    const resultEl = document.getElementById('result');
    resultEl.innerHTML = `Congratulations, you are a ${house}!`;
    resultEl.style.display = 'block';
}

// Selection functions for each house

// Gryffindor selection function (Question 1, first button)
function selectGryffindor() {
    document.getElementById('question1').style.display = 'none';
    displayResult('Gryffindor');
}

// Slytherin selection function (Question 2, first button)
function selectSlytherin() {
    document.getElementById('question2').style.display = 'none';
    displayResult('Slytherin');
}

// Ravenclaw selection function (Question 3, first button)
function selectRavenclaw() {
    document.getElementById('question3').style.display = 'none';
    displayResult('Ravenclaw');
}

// Hufflepuff selection function (Question 3, second button)
function selectHufflepuff() {
    document.getElementById('question3').style.display = 'none';
    displayResult('Hufflepuff');
}

// Cookie Banner functionality
const cookieBanner = document.getElementById("cookieBanner");
const yesButton = document.getElementById("yesButton");
const noButton = document.getElementById("noButton");

noButton.addEventListener("click", function() {
    // Hide the banner
    cookieBanner.style.display = "none";
});

yesButton.addEventListener("click", () => {
    // Change the h3 element text
    document.querySelector("#cookieBanner h3").innerHTML = "First Lesson - Don't admit that";

    // Change the p element text
    document.querySelector("#cookieBanner p").innerHTML = "But you did! So as a reward, your third year will now feature 30% extra dementor!";

    // Hide the "Yes, I am!" button
    yesButton.style.display = "none";

    // Change the "Nope" button text to "Yay!"
    noButton.innerHTML = "Yay!";
});
