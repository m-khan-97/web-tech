let currentQuestion = 1; // Track the current question

// Function to show the next question
function nextQuestion(questionNum) {
    const currentQuestionEl = document.getElementById(`question${questionNum}`);
    const nextQuestionEl = document.getElementById(`question${questionNum + 1}`);

    // Hide the current question
    currentQuestionEl.style.display = 'none';

    // Show the next question if it exists
    if (nextQuestionEl) {
        nextQuestionEl.style.display = 'block';
    }

    // If the last question is reached, show the result
    if (questionNum === 3) {
        showResult();
    }
}

// Show the result message after the last question
function showResult() {
    const resultSection = document.getElementById('result');
    resultSection.style.display = 'block';
}

// Cookie Banner functionality
const cookieBanner = document.getElementById("cookieBanner");
const yesButton = document.getElementById("yesButton");
const noButton = document.getElementById("noButton");

noButton.addEventListener("click", function() {
    // Hide the banner
    cookieBanner.style.display = "none";
});

yesButton.addEventListener("click", () => {
    // Change the h3 element text
    document.getElementById("h3").innerHTML = "First Lesson - Don't admit that";

    // Change the p element text
    document.querySelector("#cookieBanner p").innerHTML = "But you did! So as a reward, your third year will now feature 30% extra dementor!";

    // Hide the "Yes, I am!" button
    yesButton.style.display = "none";

    // Change the "Nope" button text to "Yay!"
    noButton.innerHTML = "Yay!";
});
